module Chat {
	requires java.desktop;
}